//
//  ResultsViewController.swift
//  Spelling Bee
//
//  Created by Margaret Hinote on 12/13/17.
//  Copyright © 2017 Maxx Tannenbaum & Meg Hinote. All rights reserved.
//

import Foundation
import UIKit

class ResultsViewController: UIViewController {
    @IBOutlet weak var mainList: UILabel!
    @IBOutlet weak var list7: UILabel!

    var results: [String] = []
    var results7: [String] = []
    
    override func viewDidLoad() {
        mainList.text = ""
        list7.text = ""
        for res in results {
            mainList.text = "\(res) \n"
        }
        for resie in results7 {
            list7.text = "\(resie) \n"
        }
    }
    
    
    
}
