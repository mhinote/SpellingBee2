//
//  PuzzleViewController.swift
//  Spelling Bee
//
//  Created by Margaret Hinote on 12/13/17.
//  Copyright © 2017 Maxx Tannenbaum & Meg Hinote. All rights reserved.
//

import Foundation
import UIKit

class PuzzleViewController: UIViewController {
//    @IBOutlet weak var puzzle1: UILabel!
    @IBOutlet weak var puzzle2: UILabel!
    @IBOutlet weak var puzzle3: UILabel!
    @IBOutlet weak var puzzle4: UILabel!
    @IBOutlet weak var puzzle5: UILabel!
    @IBOutlet weak var puzzle6: UILabel!
    @IBOutlet weak var puzzle7: UILabel!
    @IBOutlet weak var puzzle1: UILabel!
    
    var ourLetters: [String] = []
    var ourGoal: Int = 0
    var ourResults: [String] = []
    var PuzzleNumber = 1
    
    var gvc = GameViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func pickPuzzle1(_ sender: UITapGestureRecognizer) {
            ourGoal = 32
    }
    
    @IBAction func pickPuzzle2(_ sender: UITapGestureRecognizer) {
        PuzzleNumber = 2
        ourGoal = 19
    }
    
    @IBAction func pickPuzzle3(_ sender: UITapGestureRecognizer) {
        PuzzleNumber = 3
        ourGoal = 28
    }
    
    @IBAction func pickPuzzle4(_ sender: UITapGestureRecognizer) {
        PuzzleNumber = 4
        ourGoal = 25
    }
    
    @IBAction func pickPuzzle5(_ sender: UITapGestureRecognizer) {
        PuzzleNumber = 5
        ourGoal = 22
    }
    
    @IBAction func pickPuzzle6(_ sender: UITapGestureRecognizer) {
        PuzzleNumber = 6
        ourGoal = 24
    }
    
    @IBAction func pickPuzzle7(_ sender: UITapGestureRecognizer) {
        PuzzleNumber = 7
        ourGoal = 25
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let gvc = (segue.destination as! GameViewController)
        gvc.option = PuzzleNumber
        gvc.goal = ourGoal
        gvc.results = ourResults
    }
}
