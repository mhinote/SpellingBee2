//
//  ScoreViewController.swift
//  Spelling Bee
//
//  Created by Margaret Hinote on 12/13/17.
//  Copyright © 2017 Maxx Tannenbaum & Meg Hinote. All rights reserved.
//

import Foundation
import UIKit

class ScoreViewController: UIViewController {
    
    var userScore = 0
    var results: [String] = []
    var results7: [String] = []
    
    @IBOutlet weak var scoreField: UITextView!
 
    override func viewDidLoad() {
        scoreField.text = "Congratulations! \n \n You earned  \n \(userScore) points!"
    }
 
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let rvc = (segue.destination as! ResultsViewController)
        rvc.results = results
        rvc.results7 = results7
    }
}
