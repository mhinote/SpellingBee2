//
//  GameViewController.swift
//  Spelling Bee
//
//  Created by Maxx Tannenbaum on 11/15/17.
//  Copyright © 2017 Maxx Tannenbaum & Meg Hinote. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {
    @IBOutlet weak var puzzleNum: UILabel!
    @IBOutlet weak var goalNum: UILabel!
    @IBOutlet weak var word: UILabel!
    @IBOutlet weak var score: UILabel!
    
    @IBOutlet weak var letter1: UILabel!
    @IBOutlet weak var letter2: UILabel!
    @IBOutlet weak var letter3: UILabel!
    @IBOutlet weak var letter4: UILabel!
    @IBOutlet weak var letter5: UILabel!
    @IBOutlet weak var letter6: UILabel!
    @IBOutlet weak var letter7: UILabel!
    
    
    
    var results: [String] = [];
    var results7: [String] = [];
    var userWords: [String] = [];
    var letters = ["Y", "C", "E", "M", "N", "O", "R"];
    var letters2: [String] = []
    var goal = 0;
    var userWord = ""
    var userScore = 0
    var option = 1
    var centerLetter: String = ""
    
    override func viewDidLoad() {
        setLetters()
        
        letter2.text = letters.popLast()
        letter3.text = letters.popLast()
        letter4.text = letters.popLast()
        letter5.text = letters.popLast()
        letter6.text = letters.popLast()
        letter7.text = letters.popLast()
        letter1.text = letters.popLast()

        
        setLetters()
        for _ in letters {
            letters2.append(letters.popLast()!)
        }
        
        goalNum.text = "Goal: \(goal)"
        
    }
    
    
    @IBAction func validate(_ sender: UIButton) {
        print("validate called")
        for result in results {
            if result == userWord {
                userScore = userScore + 1;
                    if results7.contains(userWord) {
                        userScore = userScore + 2;
                    }
                score.text = "Score: \(userScore)"
                userWords.append(userWord)
            }
        }
        userWord = ""
        word.text = ""
        
    }
    

    
    @IBAction func endPuzzle(_ sender: UIButton) {
        let scoreView = ScoreViewController()
        scoreView.userScore = userScore
        scoreView.results = userWords
        scoreView.results7 = results7 
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let scoreView = (segue.destination as! ScoreViewController)
        scoreView.userScore = userScore
        scoreView.results = userWords
        scoreView.results7 = results7
    }
    
    
    func setLetters() {
        letters = ["Y", "C", "E", "M", "N", "O", "R"];
        if option == 2 {
            letters = ["Y", "C", "E", "M", "N", "O", "R"];
            results = ["CEREMONY", "CORNY", "COYER", "CRONY", "ECONOMY", "EMERY", "ENEMY", "MEMORY", "MERCY", "MERRY", "MOMMY", "MONEY", "MONEYMAN", "ORNERY", "RECENCY", "ROOOMY", "YEOMEN"]
            results7 = ["CEREMONY"]
        }
        if option == 3 {
            letters = ["U","T","A","G","N","O","R"];
            results = ["ORGANUTAN","GUARANTOR","ARGONAUT","AUGUR","AURORA", "GARGANTUAN","GAUNT","GROUT","GRUNT","GUANO","NOUGAT","OUTGO","OUTGUN","OUTRAN","RAGOUT","ROTGUT","TAUNT","TROUT","TRAUNT","TURNOUT","TUTOR"]
            results7 = ["ORGANUTAN","GUARANTOR","ARGONAUT"]
        }
        if option == 4 {
            letters = ["B","Y","A","L","O","R","T"]
            results = ["Taboo","Booty","Booby","Bratty","Abbot","Bloat","Blotto","Ballot","Arbor","Robot","Labor","Laboratory","Abort","Lobby","Booboo","toolbar","loblolly","baobob","batboy","ballboy"]
            results7=["Laboratory"]
        }
    
       
        

    }
    
   
    @IBAction func addLetter1(_ sender: UITapGestureRecognizer) {
        userWord += "\(letters2[6])"
        word.text = "\(userWord)"
        print("\(userWord)")
    }
    @IBAction func addLetter2(_ sender: UITapGestureRecognizer) {
        userWord += "\(letters2[0])"
        word.text = "\(userWord)"
    }
    @IBAction func addLetter3(_ sender: UITapGestureRecognizer) {
        userWord += "\(letters2[1])"
        word.text = "\(userWord)"
    }
    @IBAction func addLetter4(_ sender: UITapGestureRecognizer) {
        userWord += "\(letters2[2])"
        word.text = "\(userWord)"
    }
    @IBAction func addLetter5(_ sender: UITapGestureRecognizer) {
        userWord += "\(letters2[3])"
        word.text = "\(userWord)"
    }
    @IBAction func addLetter6(_ sender: UITapGestureRecognizer) {
        userWord += "\(letters2[4])"
        word.text = "\(userWord)"
    }
    @IBAction func addLetter7(_ sender: UITapGestureRecognizer) {
        userWord += "\(letters2[5])"
        word.text = "\(userWord)"
    }
    

    override var shouldAutorotate: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}
